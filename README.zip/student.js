document.addEventListener('DOMContentLoaded', () => {
  let user = window.CampusCare.currentUser();

  if (!user || user.role !== 'student') {
    alert('Please log in as a student');
    window.location.href = 'index.html';
    return;
  }

  const listEl = document.getElementById('issues-list');
  const form = document.getElementById('issue-form');

  const titleSelect = document.getElementById('issue-title');
  const titleOther = document.getElementById('issue-title-other');

  const locationType = document.getElementById('location-type');
  const blockLocationRow = document.getElementById('block-location-row');
  const campusLocationRow = document.getElementById('campus-location-row');

  const blockSelect = document.getElementById('issue-block');
  const roomSelect = document.getElementById('issue-room');
  const campusLocation = document.getElementById('campus-location');
  const locationInput = document.getElementById('issue-location');

  const fileInput = document.getElementById('issue-image');
  const reporterVerify = document.getElementById('photo-verify-reporter');
  const previewEl = document.getElementById('photo-preview');
  const blockedMessage = document.getElementById('blocked-message');

  const profilePhotoInput = document.getElementById('profile-photo-input');
  const profilePhotoPreview = document.getElementById('profile-photo-preview');
  const profilePhotoPreviewLarge = document.getElementById('profile-photo-preview-large');
  const sideStudentName = document.getElementById('side-student-name');

  const rooms = [
    'Classroom 101',
    'Classroom 102',
    'Classroom 103',
    'Classroom 201',
    'Classroom 202',
    'Classroom 203',
    'Restroom 1',
    'Restroom 2'
  ];

  const navButtons = document.querySelectorAll('.nav-btn[data-section]');
  const profileNav = document.querySelector('.nav-profile');
  const sections = document.querySelectorAll('.page-section');

  function showSection(sectionId) {
    navButtons.forEach(b => b.classList.remove('active'));
    sections.forEach(section => section.classList.remove('active-section'));

    const target = document.getElementById(sectionId);
    if (target) target.classList.add('active-section');

    const activeBtn = document.querySelector(`.nav-btn[data-section="${sectionId}"]`);
    if (activeBtn) activeBtn.classList.add('active');
  }

  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      showSection(btn.dataset.section);
    });
  });

  if (profileNav) {
    profileNav.addEventListener('click', e => {
      if (e.target.id === 'profile-photo-input') return;
      showSection('profile-section');
    });
  }

  const profileLogout = document.getElementById('profile-logout');
  if (profileLogout) {
    profileLogout.addEventListener('click', () => window.CampusCare.logout());
  }

  function loadProfilePhoto() {
    const savedPhoto = localStorage.getItem('profile_photo_' + user.username);

    if (savedPhoto) {
      if (profilePhotoPreview) profilePhotoPreview.src = savedPhoto;
      if (profilePhotoPreviewLarge) profilePhotoPreviewLarge.src = savedPhoto;
    }
  }

  if (profilePhotoInput) {
    loadProfilePhoto();

    profilePhotoInput.addEventListener('change', e => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();

      reader.onload = () => {
        localStorage.setItem('profile_photo_' + user.username, reader.result);

        if (profilePhotoPreview) profilePhotoPreview.src = reader.result;
        if (profilePhotoPreviewLarge) profilePhotoPreviewLarge.src = reader.result;
      };

      reader.readAsDataURL(file);
    });
  }

  if (user.blocked) {
    if (blockedMessage) blockedMessage.classList.remove('hidden');

    if (form) {
      form.querySelectorAll('input, textarea, select, button').forEach(el => {
        el.disabled = true;
      });
    }

    render();
    renderProfile();
    return;
  }

  if (titleSelect && titleOther) {
    titleSelect.addEventListener('change', () => {
      if (titleSelect.value === 'Other') {
        titleOther.classList.remove('hidden');
        titleOther.required = true;
      } else {
        titleOther.classList.add('hidden');
        titleOther.required = false;
        titleOther.value = '';
      }
    });
  }

  if (locationType) {
    locationType.addEventListener('change', () => {
      locationInput.value = '';

      if (locationType.value === 'block') {
        blockLocationRow.classList.remove('hidden');
        campusLocationRow.classList.add('hidden');

        blockSelect.required = true;
        roomSelect.required = true;
        campusLocation.required = false;

        campusLocation.value = '';
      } else if (locationType.value === 'campus') {
        campusLocationRow.classList.remove('hidden');
        blockLocationRow.classList.add('hidden');

        campusLocation.required = true;
        blockSelect.required = false;
        roomSelect.required = false;

        blockSelect.value = '';
        roomSelect.innerHTML = '<option value="">Select block first</option>';
        roomSelect.disabled = true;
      } else {
        blockLocationRow.classList.add('hidden');
        campusLocationRow.classList.add('hidden');

        blockSelect.required = false;
        roomSelect.required = false;
        campusLocation.required = false;
      }
    });
  }

  if (blockSelect && roomSelect && locationInput) {
    blockSelect.addEventListener('change', () => {
      const block = blockSelect.value;

      roomSelect.innerHTML = '<option value="">Select Classroom / Restroom</option>';

      if (!block) {
        roomSelect.disabled = true;
        locationInput.value = '';
        return;
      }

      rooms.forEach(room => {
        const option = document.createElement('option');
        option.value = room;
        option.textContent = room;
        roomSelect.appendChild(option);
      });

      roomSelect.disabled = false;
      locationInput.value = '';
    });

    roomSelect.addEventListener('change', () => {
      if (blockSelect.value && roomSelect.value) {
        locationInput.value = `${blockSelect.value} - ${roomSelect.value}`;
      } else {
        locationInput.value = '';
      }
    });
  }

  if (campusLocation) {
    campusLocation.addEventListener('change', () => {
      locationInput.value = campusLocation.value || '';
    });
  }

  let selectedFiles = [];

  if (fileInput) {
    fileInput.addEventListener('change', e => {
      const files = Array.from(e.target.files || []);

      if (files.length === 0) return;

      const remaining = 5 - selectedFiles.length;

      if (remaining <= 0) {
        alert('You have reached the maximum of 5 photos');
        fileInput.value = '';
        return;
      }

      if (files.length > remaining) {
        alert(`Only ${remaining} more photo(s) can be added`);
        files.splice(remaining);
      }

      selectedFiles = selectedFiles.concat(files);
      renderPreview();
      fileInput.value = '';
    });
  }

  if (previewEl) {
    previewEl.addEventListener('click', e => {
      if (!e.target.matches('.remove-photo')) return;

      const index = Number(e.target.dataset.index);
      selectedFiles.splice(index, 1);
      renderPreview();
    });
  }

  function renderPreview() {
    if (!previewEl) return;

    if (selectedFiles.length === 0) {
      previewEl.innerHTML = '';
      return;
    }

    previewEl.innerHTML = selectedFiles.map((file, index) => {
      const url = URL.createObjectURL(file);

      return `
        <div class="preview-item">
          <img src="${url}" alt="${escapeHtml(file.name)}">
          <div style="padding:8px;display:flex;justify-content:space-between;align-items:center;gap:8px;">
            <small>${escapeHtml(file.name)}</small>
            <button type="button" class="btn ghost remove-photo" data-index="${index}">
              Remove
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  function compressImage(file, maxSize = 700, quality = 0.55) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        const img = new Image();

        img.onload = () => {
          let width = img.width;
          let height = img.height;

          if (width > maxSize || height > maxSize) {
            if (width > height) {
              height = Math.round((height * maxSize) / width);
              width = maxSize;
            } else {
              width = Math.round((width * maxSize) / height);
              height = maxSize;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);

          const mime = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
          resolve(canvas.toDataURL(mime, quality));
        };

        img.onerror = () => reject(new Error('Invalid image file'));
        img.src = reader.result;
      };

      reader.onerror = () => reject(reader.error || new Error('File read error'));
      reader.readAsDataURL(file);
    });
  }

  function render() {
    const issues = window.CampusCare
      .getIssues()
      .filter(i => i.reporter === user.username);

    setText('stat-total', issues.length);
    setText('stat-new', issues.filter(i => i.status === 'Open').length);
    setText('stat-progress', issues.filter(i => i.status === 'In Progress').length);
    setText('stat-completed', issues.filter(i => i.status === 'Resolved').length);

    if (!listEl) return;

    listEl.innerHTML = issues.map(i => {
      const photos = (i.photos || [])
        .map(p => `<img class="thumb" src="${p}" alt="photo">`)
        .join('');

      const reporterBadge = i.photoVerifiedByReporter
        ? '<span class="badge verified">Reporter Verified ✅</span>'
        : '';

      const adminBadge = i.photoVerifiedByAdmin
        ? '<span class="badge verified-admin">Photo Verified ✅</span>'
        : '';

      const photoRejected = i.photoRejectedByAdmin
        ? '<span class="badge rejected">Photo Rejected ❌</span>'
        : '';

      const adminComment = i.adminComment
        ? `
          <div class="admin-comment-box">
            <strong>Admin Comment:</strong>
            <p>${escapeHtml(i.adminComment)}</p>
          </div>
        `
        : '';

      const rejectReason = i.rejectReason
        ? `
          <div class="rejected-box">
            <strong>Reject Reason:</strong>
            <p>${escapeHtml(i.rejectReason)}</p>
          </div>
        `
        : '';

      const reopenButton = i.status === 'Resolved'
        ? `
          <button class="btn ghost btn-student-reopen" data-id="${escapeHtml(i.id)}">
            Reopen Request
          </button>
        `
        : '';

      const editButton = i.status === 'Open'
        ? `
          <button class="btn ghost btn-edit-issue" data-id="${escapeHtml(i.id)}">
            Edit Complaint / Add Photos
          </button>
        `
        : '';

      return `
        <div class="issue" data-id="${escapeHtml(i.id)}">
          <div class="photos">
            ${photos || '<div class="no-photo">No Image Uploaded</div>'}
          </div>

          <div class="meta">
            <b>${escapeHtml(i.title)}</b>

            ${reporterBadge}
            ${adminBadge}
            ${photoRejected}

            <div class="badge-row">
              <span class="cat-badge">${escapeHtml(i.category || 'General')}</span>
              <span class="status-badge ${getStatusClass(i.status)}">${escapeHtml(i.status || 'Open')}</span>
            </div>

            <small>
              ${escapeHtml(i.location || 'Unknown location')}
              •
              ${new Date(i.created || Date.now()).toLocaleString()}
            </small>

            <p>${escapeHtml(i.description)}</p>

            ${adminComment}
            ${rejectReason}

            <div class="issue-actions">
              ${editButton}
              ${reopenButton}
            </div>
          </div>
        </div>
      `;
    }).join('') || '<div class="muted">No reports yet</div>';

    renderProfile();
  }

  if (form) {
    form.addEventListener('submit', e => {
      try {
        e.preventDefault();

        const rawTitle = titleSelect.value.trim();

        const title = rawTitle === 'Other'
          ? titleOther.value.trim()
          : rawTitle;

        const desc = document.getElementById('issue-desc').value.trim();
        const category = document.getElementById('issue-category').value.trim();
        const location = locationInput.value.trim();

        if (!title || !desc || !category || !location) {
          alert('Please fill all required fields');
          return;
        }

        const allIssues = window.CampusCare.getIssues();

        const duplicate = allIssues.find(i =>
          String(i.title || '').toLowerCase() === title.toLowerCase() &&
          String(i.location || '').toLowerCase() === location.toLowerCase() &&
          i.status !== 'Resolved' &&
          i.status !== 'Rejected'
        );

        if (duplicate) {
          alert('This issue has already been reported for this location and is being processed.');
          return;
        }

        if (selectedFiles.length) {
          const readers = selectedFiles.slice(0, 5).map(f => compressImage(f, 700, 0.55));

          Promise.all(readers)
            .then(results => saveIssue(results))
            .catch(err => {
              console.error(err);
              alert('Error reading files: ' + err.message);
            });
        } else {
          saveIssue([]);
        }

      } catch (err) {
        console.error('Submit error', err);
        alert('Submit failed: ' + (err && err.message ? err.message : String(err)));
      }
    });
  }

  function saveIssue(base64) {
    const rawTitle = titleSelect.value.trim();

    const issue = {
      id: 'i_' + Date.now(),
      title: rawTitle === 'Other' ? titleOther.value.trim() : rawTitle,
      description: document.getElementById('issue-desc').value.trim(),
      category: document.getElementById('issue-category').value.trim(),
      photos: Array.isArray(base64) ? base64 : [],
      reporter: user.username,
      status: 'Open',
      location: locationInput.value.trim(),
      photoVerifiedByReporter: !!reporterVerify.checked,
      photoVerifiedByAdmin: false,
      photoRejectedByAdmin: false,
      adminComment: '',
      rejectReason: '',
      reopened: false,
      reopenNotification: false,
      reopenMessage: '',
      created: Date.now(),
      history: [
        {
          status: 'Open',
          date: Date.now()
        }
      ]
    };

    const removed = window.CampusCare.addIssue(issue);

    form.reset();
    selectedFiles = [];
    previewEl.innerHTML = '';

    titleOther.classList.add('hidden');
    titleOther.required = false;

    blockLocationRow.classList.add('hidden');
    campusLocationRow.classList.add('hidden');

    roomSelect.innerHTML = '<option value="">Select block first</option>';
    roomSelect.disabled = true;

    locationInput.value = '';
    reporterVerify.checked = false;

    if (removed) {
      alert(`Issue submitted successfully! ${removed} older report${removed === 1 ? '' : 's'} were removed to free storage.`);
    } else {
      alert('Issue submitted successfully!');
    }

    render();
    renderProfile();
  }

  if (listEl) {
    listEl.addEventListener('click', e => {
      if (e.target.matches('.btn-student-reopen')) {
        const id = e.target.dataset.id;

        window.CampusCare.updateIssue(id, {
          status: 'Open',
          reopened: true,
          reopenNotification: true,
          reopenMessage: 'Student reopened this complaint. Please review again.',
          reopenedAt: Date.now()
        });

        alert('Request reopened and sent back to admin');
        render();
        renderProfile();
      }

      if (e.target.matches('.btn-edit-issue')) {
        const id = e.target.dataset.id;
        const issues = window.CampusCare.getIssues();
        const issue = issues.find(i => i.id === id);

        if (!issue) return;

        const newDesc = prompt('Edit complaint description:', issue.description || '');

        if (newDesc === null) return;

        if (!newDesc.trim()) {
          alert('Description cannot be empty');
          return;
        }

        const addPhoto = confirm('Do you want to add more photos to this complaint?');

        if (!addPhoto) {
          window.CampusCare.updateIssue(id, {
            description: newDesc.trim(),
            editedAt: Date.now()
          });

          alert('Complaint updated successfully');
          render();
          return;
        }

        const filePicker = document.createElement('input');
        filePicker.type = 'file';
        filePicker.accept = 'image/*';
        filePicker.multiple = true;

        filePicker.onchange = async () => {
          try {
            const files = Array.from(filePicker.files || []);
            const oldPhotos = Array.isArray(issue.photos) ? issue.photos : [];
            const remaining = 5 - oldPhotos.length;

            if (remaining <= 0) {
              alert('Maximum 5 photos already uploaded.');
              return;
            }

            if (files.length === 0) {
              window.CampusCare.updateIssue(id, {
                description: newDesc.trim(),
                editedAt: Date.now()
              });

              alert('Complaint updated successfully');
              render();
              return;
            }

            if (files.length > remaining) {
              alert(`Only ${remaining} more photo(s) can be added.`);
            }

            const selected = files.slice(0, remaining);

            const compressedPhotos = await Promise.all(
              selected.map(file => compressImage(file, 700, 0.55))
            );

            window.CampusCare.updateIssue(id, {
              description: newDesc.trim(),
              photos: oldPhotos.concat(compressedPhotos),
              photoVerifiedByAdmin: false,
              photoRejectedByAdmin: false,
              editedAt: Date.now()
            });

            alert('Complaint updated with new photos');
            render();

          } catch (err) {
            console.error(err);
            alert('Error adding photos');
          }
        };

        filePicker.click();
      }
    });
  }

  document.addEventListener('blur', e => {
    if (!e.target.matches('.editable-profile')) return;

    const field = e.target.dataset.field;
    const value = e.target.textContent.trim();

    if (!field) return;

    window.CampusCare.updateUser(user.username, {
      [field]: value
    });

    user = window.CampusCare.currentUser();
    renderProfile();
  }, true);

  function renderProfile() {
    user = window.CampusCare.currentUser();

    if (sideStudentName) {
      sideStudentName.textContent = user.name || user.username;
    }

    setText('profile-name', user.name || '-');
    setText('profile-roll', user.roll || '-');
    setText('profile-department', user.department || '-');
    setText('profile-year', user.year || '-');
    setText('profile-section-text', user.section || '-');
    setText('profile-email', user.username || '-');

    loadProfilePhoto();
  }

  let zoomLevel = 1;

  document.addEventListener('click', e => {
    if (!e.target.matches('.thumb')) return;

    const modal = document.getElementById('image-modal');
    const modalImg = document.getElementById('modal-image');

    if (!modal || !modalImg) return;

    zoomLevel = 1;
    modalImg.src = e.target.src;
    modalImg.style.transform = `scale(${zoomLevel})`;
    modal.classList.remove('hidden');
  });

  const closeBtn = document.getElementById('modal-close');
  const zoomIn = document.getElementById('zoom-in');
  const zoomOut = document.getElementById('zoom-out');

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      document.getElementById('image-modal').classList.add('hidden');
    });
  }

  if (zoomIn) {
    zoomIn.addEventListener('click', () => {
      zoomLevel += 0.2;
      document.getElementById('modal-image').style.transform = `scale(${zoomLevel})`;
    });
  }

  if (zoomOut) {
    zoomOut.addEventListener('click', () => {
      zoomLevel = Math.max(0.5, zoomLevel - 0.2);
      document.getElementById('modal-image').style.transform = `scale(${zoomLevel})`;
    });
  }

  function getStatusClass(status) {
    if (status === 'Resolved') return 'resolved';
    if (status === 'In Progress') return 'in-progress';
    if (status === 'Rejected') return 'rejected';
    return '';
  }

  function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
  }

  function escapeHtml(s) {
    return String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  render();
  renderProfile();
});