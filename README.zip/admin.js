document.addEventListener('DOMContentLoaded', () => {
  let user = window.CampusCare.currentUser();

  if (!user || user.role !== 'admin') {
    alert('Please login as Admin');
    window.location.href = 'index.html';
    return;
  }

  const issueList = document.getElementById('admin-issues');
  const activeList = document.getElementById('active-admin-issues');
  const studentList = document.getElementById('student-list');

  const adminSearch = document.getElementById('admin-search');
  const statusFilter = document.getElementById('filter-status');
  const categoryFilter = document.getElementById('filter-category');
  const studentSearch = document.getElementById('student-search');

  const sideAdminName = document.getElementById('side-admin-name');
  const adminPhotoInput = document.getElementById('admin-profile-photo-input');
  const adminPhotoPreview = document.getElementById('admin-profile-photo-preview');

  const navButtons = document.querySelectorAll('.nav-btn[data-section]');
  const sections = document.querySelectorAll('.page-section');

  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      navButtons.forEach(b => b.classList.remove('active'));
      sections.forEach(s => s.classList.remove('active-section'));

      btn.classList.add('active');

      const target = document.getElementById(btn.dataset.section);
      if (target) target.classList.add('active-section');
    });
  });

  const logoutBtn = document.getElementById('btn-logout');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      window.CampusCare.logout();
    });
  }

  function loadAdminPhoto() {
    const savedPhoto = localStorage.getItem('profile_photo_' + user.username);

    if (savedPhoto && adminPhotoPreview) {
      adminPhotoPreview.src = savedPhoto;
    }
  }

  if (adminPhotoInput && adminPhotoPreview) {
    loadAdminPhoto();

    adminPhotoInput.addEventListener('change', e => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();

      reader.onload = () => {
        adminPhotoPreview.src = reader.result;
        localStorage.setItem('profile_photo_' + user.username, reader.result);
      };

      reader.readAsDataURL(file);
    });
  }

  function getStudent(username) {
    return window.CampusCare.getUsers().find(u => u.username === username);
  }

  function getStudentsWithComplaints() {
    const issues = window.CampusCare.getIssues();
    const reportedUsernames = [...new Set(issues.map(i => i.reporter))];

    return window.CampusCare.getUsers()
      .filter(u => u.role === 'student')
      .filter(u => reportedUsernames.includes(u.username));
  }

  function renderProfile() {
    user = window.CampusCare.currentUser();

    const studentsWithComplaints = getStudentsWithComplaints();

    setText('admin-name', user.name || user.username.split('@')[0]);
    setText('admin-role', 'Campus Administrator');
    setText('student-total', studentsWithComplaints.length);
    setText('student-blocked', studentsWithComplaints.filter(s => s.blocked).length);

    if (sideAdminName) {
      sideAdminName.textContent = user.name || 'Admin Panel';
    }
  }

  document.addEventListener('blur', e => {
    if (!e.target.matches('.editable-admin-profile')) return;

    const field = e.target.dataset.field;
    const value = e.target.textContent.trim();

    if (!field) return;

    window.CampusCare.updateUser(user.username, {
      [field]: value
    });

    user = window.CampusCare.currentUser();
    renderProfile();
  }, true);

  function renderStudents() {
    const query = (studentSearch.value || '').toLowerCase();

    const students = getStudentsWithComplaints()
      .filter(student =>
        String(student.name || '').toLowerCase().includes(query) ||
        String(student.username || '').toLowerCase().includes(query) ||
        String(student.roll || '').toLowerCase().includes(query)
      );

    const issues = window.CampusCare.getIssues();

    if (!studentList) return;

    studentList.innerHTML = students.map(student => {
      const studentIssues = issues.filter(i => i.reporter === student.username);

      const open = studentIssues.filter(i => i.status === 'Open').length;
      const progress = studentIssues.filter(i => i.status === 'In Progress').length;
      const resolved = studentIssues.filter(i => i.status === 'Resolved').length;
      const rejected = studentIssues.filter(i => i.status === 'Rejected').length;

      const photo = localStorage.getItem('profile_photo_' + student.username);

      return `
        <div class="student-card">
          <div class="student-info student-info-with-photo">
            <img
              class="mini-profile-photo"
              src="${photo || 'https://via.placeholder.com/80'}"
              alt="Student">

            <div>
              <b>${escapeHtml(student.name || student.username)}</b>
              <small>${escapeHtml(student.username)}</small>

              <p>
                Roll No: ${escapeHtml(student.roll || '-')} •
                Department: ${escapeHtml(student.department || '-')} •
                Year: ${escapeHtml(student.year || '-')} •
                Section: ${escapeHtml(student.section || '-')}
              </p>

              <p>
                <span class="chip">Total: ${studentIssues.length}</span>
                <span class="chip">Open: ${open}</span>
                <span class="chip">Progress: ${progress}</span>
                <span class="chip">Resolved: ${resolved}</span>
                <span class="chip">Rejected: ${rejected}</span>
              </p>

              <p>${student.blocked ? 'Blocked by admin' : 'Active student user'}</p>
            </div>
          </div>

          <div class="student-actions">
            <span class="status-chip ${student.blocked ? 'blocked' : 'active'}">
              ${student.blocked ? 'Blocked' : 'Active'}
            </span>

            <button class="btn ghost btn-block" data-username="${escapeHtml(student.username)}">
              ${student.blocked ? 'Unblock' : 'Block'}
            </button>
          </div>
        </div>
      `;
    }).join('') || '<div class="muted">No students have submitted complaints yet.</div>';
  }

  function renderIssues() {
    let issues = window.CampusCare.getIssues();
    const users = window.CampusCare.getUsers();

    setText('admin-total', issues.length);
    setText('admin-open', issues.filter(i => i.status === 'Open').length);
    setText('admin-progress', issues.filter(i => i.status === 'In Progress').length);
    setText('admin-resolved', issues.filter(i => i.status === 'Resolved').length);

    const active = issues.filter(i =>
      i.status === 'Open' ||
      i.status === 'In Progress'
    );

    if (activeList) {
      activeList.innerHTML = active.slice(0, 5).map(i => {
        const student = getStudent(i.reporter);

        return `
          <div class="issue">
            <div class="meta">
              <b>${escapeHtml(i.title)}</b>

              ${i.reopenNotification ? `
                <div class="reopen-alert">
                  🔔 Student reopened this complaint. Please review again.
                </div>
              ` : ''}

              <div class="badge-row">
                <span class="cat-badge">${escapeHtml(i.category || 'General')}</span>
                <span class="status-badge ${getStatusClass(i.status)}">
                  ${escapeHtml(i.status || 'Open')}
                </span>
              </div>

              <small>
                ${escapeHtml(i.location || 'Unknown location')}
                • by ${escapeHtml(student?.name || i.reporter || 'Unknown')}
              </small>
            </div>
          </div>
        `;
      }).join('') || '<div class="muted">No active complaints.</div>';
    }

    const search = (adminSearch.value || '').toLowerCase();
    const status = statusFilter.value;
    const category = categoryFilter.value;

    if (search) {
      issues = issues.filter(i => {
        const student = users.find(u => u.username === i.reporter);

        return (
          String(i.title || '').toLowerCase().includes(search) ||
          String(i.location || '').toLowerCase().includes(search) ||
          String(i.reporter || '').toLowerCase().includes(search) ||
          String(i.description || '').toLowerCase().includes(search) ||
          String(student?.name || '').toLowerCase().includes(search) ||
          String(student?.roll || '').toLowerCase().includes(search) ||
          String(student?.department || '').toLowerCase().includes(search) ||
          String(student?.section || '').toLowerCase().includes(search)
        );
      });
    }

    if (status) {
      issues = issues.filter(i => i.status === status);
    }

    if (category) {
      issues = issues.filter(i => i.category === category);
    }

    if (!issueList) return;

    issueList.innerHTML = issues.map(i => {
      const student = getStudent(i.reporter);
      const hasPhotos = Array.isArray(i.photos) && i.photos.length > 0;

      const photos = hasPhotos
        ? i.photos.map(p => `<img class="thumb" src="${p}" alt="Complaint photo">`).join('')
        : '<div class="no-photo">No Image Uploaded</div>';

      const adminCommentBox = i.adminComment
        ? `
          <div class="admin-comment-box">
            <strong>Admin Comment:</strong>
            <p>${escapeHtml(i.adminComment)}</p>
          </div>
        `
        : '';

      const rejectBox = i.rejectReason
        ? `
          <div class="rejected-box">
            <strong>Reject Reason:</strong>
            <p>${escapeHtml(i.rejectReason)}</p>
          </div>
        `
        : '';

      const reopenAlert = i.reopenNotification
        ? `
          <div class="reopen-alert">
            🔔 Student reopened this complaint. Please review again.
          </div>
        `
        : '';

      const photoStatus = hasPhotos
        ? `
          <div class="photo-status">
            ${
              i.photoVerifiedByAdmin
                ? '<span class="badge verified-admin">Photo Verified ✅</span>'
                : i.photoRejectedByAdmin
                  ? '<span class="badge rejected">Photo Rejected ❌</span>'
                  : '<span class="badge">Photo Pending</span>'
            }
          </div>
        `
        : '';

      const photoButtons = hasPhotos && !i.photoVerifiedByAdmin && !i.photoRejectedByAdmin
        ? `
          <button class="btn ghost btn-photo-verify" data-id="${escapeHtml(i.id)}">
            Verify Photo
          </button>

          <button class="btn ghost btn-photo-reject" data-id="${escapeHtml(i.id)}">
            Reject Photo
          </button>
        `
        : '';

      const rejectButton = i.status !== 'Rejected' && i.status !== 'Resolved'
        ? `
          <button class="btn ghost btn-reject" data-id="${escapeHtml(i.id)}">
            Reject
          </button>
        `
        : '';

      const reopenButton = i.status === 'Resolved' || i.status === 'Rejected'
        ? `
          <button class="btn ghost btn-reopen" data-id="${escapeHtml(i.id)}">
            Reopen
          </button>
        `
        : '';

      return `
        <div class="issue">
          <div class="photos">
            ${photos}
          </div>

          <div class="meta">
            <b>${escapeHtml(i.title)}</b>

            ${reopenAlert}

            <small>
              Student: ${escapeHtml(student?.name || i.reporter || 'Unknown')}
              ${student?.roll ? ' • Roll: ' + escapeHtml(student.roll) : ''}
              • ${escapeHtml(i.location || 'Unknown location')}
            </small>

            <div class="badge-row">
              <span class="cat-badge">${escapeHtml(i.category || 'General')}</span>
              <span class="status-badge ${getStatusClass(i.status)}">
                ${escapeHtml(i.status || 'Open')}
              </span>
            </div>

            <p>${escapeHtml(i.description || '')}</p>

            ${photoStatus}
            ${adminCommentBox}
            ${rejectBox}

            <textarea
              class="admin-comment-input"
              data-id="${escapeHtml(i.id)}"
              placeholder="Add admin comment..."
            >${escapeHtml(i.adminComment || '')}</textarea>

            <div class="issue-actions">
              <select class="status-select" data-id="${escapeHtml(i.id)}">
                <option ${i.status === 'Open' ? 'selected' : ''}>Open</option>
                <option ${i.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
                <option ${i.status === 'Resolved' ? 'selected' : ''}>Resolved</option>
                <option ${i.status === 'Rejected' ? 'selected' : ''}>Rejected</option>
              </select>

              <button class="btn ghost btn-save-comment" data-id="${escapeHtml(i.id)}">
                Save Comment
              </button>

              ${photoButtons}
              ${rejectButton}
              ${reopenButton}
            </div>
          </div>
        </div>
      `;
    }).join('') || '<div class="muted">No complaints found.</div>';

    renderNotifications();
  }

  if (studentList) {
    studentList.addEventListener('click', e => {
      if (!e.target.matches('.btn-block')) return;

      const username = e.target.dataset.username;
      const student = window.CampusCare.getUsers().find(s => s.username === username);

      if (!student) return;

      window.CampusCare.updateUser(username, {
        blocked: !student.blocked
      });

      renderProfile();
      renderStudents();
    });
  }

  if (issueList) {
    issueList.addEventListener('change', e => {
      if (!e.target.matches('.status-select')) return;

      const id = e.target.dataset.id;
      const newStatus = e.target.value;

      if (newStatus === 'Rejected') {
        const reason = prompt('Enter rejection reason:');

        if (!reason || !reason.trim()) {
          alert('Reject reason is required.');
          renderIssues();
          return;
        }

        window.CampusCare.updateIssue(id, {
          status: 'Rejected',
          rejectReason: reason.trim(),
          rejectedAt: Date.now(),
          reopenNotification: false
        });

        alert('Complaint rejected');
        renderIssues();
        return;
      }

      window.CampusCare.updateIssue(id, {
        status: newStatus,
        reopenNotification: false
      });

      renderIssues();
    });

    issueList.addEventListener('click', e => {
      const id = e.target.dataset.id;

      if (e.target.matches('.btn-save-comment')) {
        const input = document.querySelector(`.admin-comment-input[data-id="${id}"]`);

        window.CampusCare.updateIssue(id, {
          adminComment: input.value.trim(),
          commentUpdatedAt: Date.now()
        });

        alert('Admin comment saved');
        renderIssues();
      }

      if (e.target.matches('.btn-reject')) {
        const reason = prompt('Enter rejection reason:');

        if (!reason || !reason.trim()) {
          alert('Reject reason is required.');
          return;
        }

        window.CampusCare.updateIssue(id, {
          status: 'Rejected',
          rejectReason: reason.trim(),
          rejectedAt: Date.now(),
          reopenNotification: false
        });

        alert('Complaint rejected');
        renderIssues();
      }

      if (e.target.matches('.btn-reopen')) {
        window.CampusCare.updateIssue(id, {
          status: 'Open',
          reopened: true,
          reopenedAt: Date.now(),
          rejectReason: '',
          reopenNotification: false
        });

        alert('Complaint reopened');
        renderIssues();
      }

      if (e.target.matches('.btn-photo-verify')) {
        window.CampusCare.updateIssue(id, {
          photoVerifiedByAdmin: true,
          photoRejectedByAdmin: false
        });

        alert('Photo verified');
        renderIssues();
      }

      if (e.target.matches('.btn-photo-reject')) {
        window.CampusCare.updateIssue(id, {
          photoVerifiedByAdmin: false,
          photoRejectedByAdmin: true
        });

        alert('Photo rejected');
        renderIssues();
      }
    });
  }

  function renderNotifications() {
    const notifCount = document.getElementById('notif-count');
    const panel = document.getElementById('notification-panel');

    if (!notifCount || !panel) return;

    const issues = window.CampusCare.getIssues();
    const notifications = issues.filter(i => i.reopenNotification === true);

    notifCount.textContent = notifications.length;

    if (notifications.length === 0) {
      notifCount.style.display = 'none';
      panel.innerHTML = '<div class="notification-empty">No new notifications</div>';
      return;
    }

    notifCount.style.display = 'flex';

    panel.innerHTML = notifications.map(i => `
      <div class="notification-item" data-id="${escapeHtml(i.id)}">
        <strong>Reopened Complaint</strong>
        <p>${escapeHtml(i.reopenMessage || 'Student reopened this complaint')}</p>
        <small>${escapeHtml(i.title || 'Complaint')} • ${escapeHtml(i.location || '')}</small>
      </div>
    `).join('');
  }

  const bell = document.getElementById('notification-bell');
  const panel = document.getElementById('notification-panel');

  if (bell && panel) {
    bell.addEventListener('click', () => {
      panel.classList.toggle('hidden');
      renderNotifications();
    });

    panel.addEventListener('click', e => {
      const item = e.target.closest('.notification-item');

      if (!item) return;

      const id = item.dataset.id;
      const issues = window.CampusCare.getIssues();
      const issue = issues.find(i => i.id === id);

      alert(issue?.reopenMessage || 'Student reopened this complaint. Please review again.');

      window.CampusCare.updateIssue(id, {
        reopenNotification: false
      });

      renderNotifications();
      renderIssues();
    });
  }

  if (adminSearch) adminSearch.addEventListener('input', renderIssues);
  if (statusFilter) statusFilter.addEventListener('change', renderIssues);
  if (categoryFilter) categoryFilter.addEventListener('change', renderIssues);
  if (studentSearch) studentSearch.addEventListener('input', renderStudents);

  const toggle = document.getElementById('admin-theme-toggle');

  if (toggle) {
    toggle.checked =
      window.CampusCare.getTheme &&
      window.CampusCare.getTheme() === 'dark';

    toggle.addEventListener('change', () => {
      if (window.CampusCare.setTheme) {
        window.CampusCare.setTheme(toggle.checked ? 'dark' : 'light');
      } else {
        const theme = toggle.checked ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('cc_theme', theme);
      }
    });
  }

  let zoomLevel = 1;

  document.addEventListener('click', e => {
    if (!e.target.matches('.thumb')) return;

    const modal = document.getElementById('image-modal');
    const modalImg = document.getElementById('modal-image');

    if (!modal || !modalImg) return;

    zoomLevel = 1;
    modalImg.src = e.target.src;
    modalImg.style.transform = `scale(${zoomLevel})`;
    modal.classList.remove('hidden');
  });

  const closeBtn = document.getElementById('modal-close');
  const zoomIn = document.getElementById('zoom-in');
  const zoomOut = document.getElementById('zoom-out');

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      document.getElementById('image-modal').classList.add('hidden');
    });
  }

  if (zoomIn) {
    zoomIn.addEventListener('click', () => {
      zoomLevel += 0.2;
      document.getElementById('modal-image').style.transform = `scale(${zoomLevel})`;
    });
  }

  if (zoomOut) {
    zoomOut.addEventListener('click', () => {
      zoomLevel = Math.max(0.5, zoomLevel - 0.2);
      document.getElementById('modal-image').style.transform = `scale(${zoomLevel})`;
    });
  }

  function getStatusClass(status) {
    if (status === 'Resolved') return 'resolved';
    if (status === 'In Progress') return 'in-progress';
    if (status === 'Rejected') return 'rejected';
    return '';
  }

  function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  renderProfile();
  renderStudents();
  renderIssues();
  renderNotifications();
});